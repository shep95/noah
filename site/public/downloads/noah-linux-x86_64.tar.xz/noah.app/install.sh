#!/usr/bin/env sh
# Installs noah for the current user: ~/.local/noah.app, a `noah` command in
# ~/.local/bin, and a launcher entry. Run with --uninstall to remove it.
set -eu
here="$(cd "$(dirname "$0")" && pwd)"
target="$HOME/.local/noah.app"
bin_dir="$HOME/.local/bin"
apps_dir="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
desktop="$apps_dir/com.asherin.noah.desktop"

if [ "${1:-}" = "--uninstall" ]; then
    rm -rf "$target" "$bin_dir/noah" "$desktop"
    echo "noah removed."
    exit 0
fi

if [ "$here" != "$target" ]; then
    rm -rf "$target"
    mkdir -p "$(dirname "$target")"
    cp -R "$here" "$target"
fi
mkdir -p "$bin_dir" "$apps_dir"
ln -sf "$target/bin/noah" "$bin_dir/noah"
sed -e "s|^TryExec=noah|TryExec=$target/bin/noah|" \
    -e "s|^Exec=noah|Exec=$target/bin/noah|" \
    -e "s|^Icon=noah|Icon=$target/share/icons/hicolor/512x512/apps/noah.png|" \
    "$target/share/applications/com.asherin.noah.desktop" > "$desktop"
chmod +x "$desktop"
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$apps_dir" >/dev/null 2>&1 || true
echo "noah is installed. Open it from your app launcher, or run: noah"
case ":$PATH:" in *":$bin_dir:"*) ;; *) echo "(add $bin_dir to your PATH to use the noah command)";; esac
